Rails.application.routes.draw do

  get '' => "application#index"
  get '/main' => "sessions#index"
  post '/sessions' =>"sessions#create"
  delete '/sessions/destroy' => "sessions#destroy", as: "destroy_session"

  get '/users' => "users#index", as: "all_users"
  post '/users' => 'users#create'
  get '/users/:id'=> 'users#show'

  post 'users/add/:id' => "friendships#create", as: "add_friend"
  delete 'users/ignore/:id' => "requests#destroy", as: "ignore_request"

  post 'users/request/:id' => "requests#create", as: "send_request"

  get '/professional_profile' => "profiles#index", as: "user_profile"
end
