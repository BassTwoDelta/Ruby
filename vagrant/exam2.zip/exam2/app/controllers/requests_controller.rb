class RequestsController < ApplicationController

    def create
        other_user = User.find(params[:id])
        unless other_user.requests.include?(current_user)
            new_request = Request.new 
            new_request.requestor = current_user
            new_request.receiver = other_user
            new_request.save
        end
        redirect_to "/professional_profile"
    end

    def destroy 
        Request.destroy(params[:id])
        redirect_to "/professional_profile"
    end
end
