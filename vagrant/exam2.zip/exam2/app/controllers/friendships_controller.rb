class FriendshipsController < ApplicationController

    def create
        unless current_user.friendships.include?(params[:id])
            new_friendship = Friendship.new
            new_friendship.user = current_user
            new_friendship.friend = User.find(params[:id])
            new_friendship.save 
            new_friendship2 = Friendship.new 
            new_friendship2.user = User.find(params[:id])
            new_friendship2.friend = current_user 
            new_friendship2.save 
            request = Request.where(requestor: params[:id], receiver: current_user)
            request.destroy_all
        end
        redirect_to '/professional_profile'
    end
end
