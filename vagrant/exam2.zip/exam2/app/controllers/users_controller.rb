class UsersController < ApplicationController

    before_action :require_login, only: [:index]

    def index
        @users = User.all_except(current_user)
    end

    def create
        @user = User.create(register_user_params)
        if @user.save
            session[:user_id] = @user.id
            redirect_to '/professional_profile'
        else 
            flash[:errors] = @user.errors.full_messages
            redirect_to '/main'
        end
    end
    
    def show
        @user = User.find(params[:id])
    end
    
    def register_user_params
        params.require(:user).permit(:name, :email, :password, :password_confirmation, :description)
    end

end
