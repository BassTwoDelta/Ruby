class User < ActiveRecord::Base
  EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  has_secure_password
  has_many :friendships, dependent: :destroy
  has_many :friends, through: :friendships
  has_many :friend_requests_as_requester, foreign_key: :requestor_id, class_name: "Request"
  has_many :friend_requests_as_reciever, foreign_key: :receiver_id, class_name: "Request"
  validates :email, presence: true, format: {with: EMAIL_REGEX}, uniqueness: true
  validates :password, presence: true, length: {minimum: 8}
  validates :description, presence: true, length: {minimum: 5}
  before_save { email.downcase! }
  # this below was so complicated for me to figure out and I Am sure there is a much easier way.... LOL
  scope :all_except, ->(user) { where.not(id: (user.friends + [user]).map(&:id))}
end
