require 'test_helper'

class RequestsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
