require 'test_helper'

class FriendshipsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
